%   HWSRIVC_CL obsolte function name, which is now replace by clsrivc2_hw


