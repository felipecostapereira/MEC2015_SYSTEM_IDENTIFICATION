% g(xbar)=xbar+NL_W(2)*xbar.^2+NL_W(3)*xbar.^3;


