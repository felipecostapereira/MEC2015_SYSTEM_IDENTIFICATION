% Prediction step


