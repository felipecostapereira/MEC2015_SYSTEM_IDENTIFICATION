% $$$    SRIV2   Computes the discrete-time model parameters from sampled I/O data by the
% $$$    Refined Instrumental Variable for hybrid continuous-time Output-Error model,
% $$$    See SRIVC2 for details


