%                 if ctmodel.nf == nf(i)
%                     ctmodel.InputDelay=nk(i)*data.Ts; % Warning: The delay has
%                     % to be handled outside of par2poly
%                     imodel = [imodel, ctmodel];
%                 else
%                     imodel = []; break;
%                 end


