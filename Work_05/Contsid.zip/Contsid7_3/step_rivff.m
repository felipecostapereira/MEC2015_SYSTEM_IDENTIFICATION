% gamma is used to check persistent of excitation
% (see book [Astrom 2008], p. 477)


