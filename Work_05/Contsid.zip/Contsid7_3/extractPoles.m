%A =Ab*sigA;


