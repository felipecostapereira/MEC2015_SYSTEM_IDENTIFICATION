% I=find(tu<=t);
% u=u(I(end));
% e=e(I(end));


