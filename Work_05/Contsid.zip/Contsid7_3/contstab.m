%stabilies a continuous time filter


