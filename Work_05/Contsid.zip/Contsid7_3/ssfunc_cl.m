% $$$ e_H(n,1)=0;
% $$$ e_H2=[e_H; Bc*r];  % state noise


