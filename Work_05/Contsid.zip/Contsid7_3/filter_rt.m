% dtEquiv : discrete-time equivalent


