%	author   : Eric Huselstein - Hugues Garnier
%	date     : 01 March 2004
%	revision :
%	name     : timescale.m


